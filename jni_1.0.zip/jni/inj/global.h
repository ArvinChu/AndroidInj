/*
 * global.h
 *
 *  Created on: Oct 10, 2019
 *      Author: chumin
 */

#ifndef JNI_INJ_GLOBAL_H_
#define JNI_INJ_GLOBAL_H_

#include <elf.h>

static const char *INJECT_PROCESS_INFO_FILE = "/data/inject_info";
static const char *PIPE_NAME = "/data/hook_poll";

#define SOINFO_NAME_LEN 128

#ifdef ANDROID
typedef struct pt_regs regs_t;
#else
typedef struct user_regs_struct regs_t;
#endif

struct link_map {
  uintptr_t l_addr;
  char * l_name;
  uintptr_t l_ld;
  struct link_map * l_next;
  struct link_map * l_prev;
};

struct soinfo {
  char name[SOINFO_NAME_LEN];
  const Elf32_Phdr* phdr;
  int phnum;
  unsigned entry;
  unsigned base;
  unsigned size;

  int unused;  // DO NOT USE, maintained for compatibility.

  unsigned* dynamic;

  unsigned unused2; // DO NOT USE, maintained for compatibility
  unsigned unused3; // DO NOT USE, maintained for compatibility

  struct soinfo* next;
  unsigned flags;

  const char* strtab;
  Elf32_Sym* symtab;

  unsigned nbucket;
  unsigned nchain;
  unsigned* bucket;
  unsigned* chain;

  unsigned* plt_got;

  Elf32_Rel* plt_rel;
  unsigned plt_rel_count;

  Elf32_Rel* rel;
  unsigned rel_count;

  unsigned* preinit_array;
  unsigned preinit_array_count;

  unsigned* init_array;
  unsigned init_array_count;
  unsigned* fini_array;
  unsigned fini_array_count;

  void (*init_func)();
  void (*fini_func)();

#if defined(ANDROID_ARM_LINKER)
  // ARM EABI section used for stack unwinding.
  unsigned* ARM_exidx;
  unsigned ARM_exidx_count;
#elif defined(ANDROID_MIPS_LINKER)
#if 0
  // Not yet.
  unsigned* mips_pltgot
#endif
  unsigned mips_symtabno;
  unsigned mips_local_gotno;
  unsigned mips_gotsym;
#endif

  unsigned refcount;
  struct link_map linkmap;
};


/*dl function list */
typedef struct dl_fl{
	long handle; // dlopen返回的handle
    long l_dlopen;
    long l_dlclose;
    long l_dlsym;
}dl_fl_t;


struct dyn_info{
	/**
	 * 符号表的地址
	 */
    Elf32_Addr symtab;
    /**
     * 字符串表的地址
     */
    Elf32_Addr strtab;
    /**
     * 与过程链接表单独关联的第一个重定位项的地址
     */
    Elf32_Addr jmprel;
    /**
     * 重定位项的总大小
     */
    Elf32_Word totalrelsize;
    /**
     * 重定位项的大小
     */
    Elf32_Word relsize;
    /**
     * 重定位项的数量
     */
    Elf32_Word nrels;
};


struct elf_info {
	/**
	 * 进程ID
	 */
    int pid;
    Elf32_Addr base;
    Elf32_Ehdr ehdr;
    Elf32_Phdr phdr;
    Elf32_Dyn dyn;
    Elf32_Addr dynaddr;
    /**
     * GOT表项为Elf32_Addr结构
     */
    Elf32_Word got;
    Elf32_Addr phdr_addr;
    /**
     * GOT[1] 动态库映射信息数据结构 link_map 地址
     */
    Elf32_Addr map_addr;
    Elf32_Word nchains;
};


typedef enum {
    PAT_INT,
    PAT_STR,
    PAT_MEM
}ptrace_arg_type;


typedef struct {
    ptrace_arg_type type;
    unsigned long _stackid; //private only visible in ptrace_call
    union {
        int i;
        char *s;
        struct {
            int size;
            void *addr;
        }mem;
    };
}ptrace_arg;


struct process_info {
	int pid; // 进程ID
	dl_fl_t ldl;
	unsigned long start_hook_address; // hook函数地址
	unsigned long symbol_address; // 替换函数地址
	unsigned long function_address; // hook函数地址
	unsigned long function_data; // hook函数地址中原始数据
};

#endif /* JNI_INJ_GLOBAL_H_ */
