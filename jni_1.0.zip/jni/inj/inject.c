/*
 * inject.c
 *
 *  Created on: Jun 4, 2011
 *      Author: d
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dlfcn.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <jni.h>
#include <fcntl.h>

#include "global_function.h"

struct process_info processinfo;

/**
 * 获取文件名
 * @param path 文件路径
 *
 * @return 文件名
 */
char* find_file_name(const char *path)
{
	char *name_start = NULL;
	int sep = '/';
	if (NULL == path) {
	    return NULL;
	}
	name_start = strrchr(path, sep);

	return (NULL == name_start) ? path : (name_start + 1);
}

/**
 * 如果hook进程被阻塞，则通知其结束阻塞
 */
void write_pipe() {
	int fd;
	if((fd = open(PIPE_NAME, O_WRONLY | O_NONBLOCK)) < 0) {
		LOGE("write_pipe open %s failed! errno %d", PIPE_NAME, errno);
		return;
	}
	close(fd);
	// waiting read
	usleep(50000);
}

/**
 * 根据进程名称查找进程ID
 *
 * @param process_name : 进程名称
 *
 * @return 进程ID
 */
int find_pid_of(const char *process_name) {
    int id;
    pid_t pid = -1;
    DIR* dir;
    FILE *fp;
    char filename[32];
    char cmdline[256];

    struct dirent * entry;

    if (process_name == NULL)
        return -1;

    dir = opendir("/proc");
    if (dir == NULL)
        return -1;

    while((entry = readdir(dir)) != NULL) {
        id = atoi(entry->d_name);
        if (id != 0) {
            sprintf(filename, "/proc/%d/cmdline", id);
            fp = fopen(filename, "r");
            if (fp) {
                fgets(cmdline, sizeof(cmdline), fp);
                fclose(fp);

                if (strcmp(process_name, cmdline) == 0) {
                    /* process found */
                    pid = id;
                    break;
                }
            }
        }
    }

    closedir(dir);
    return pid;
}

/**
 * 使用dlopen加载hook库文件，并返回hook函数地址
 *
 * @param function_name : hook函数名称
 * @param load_library_path : hook库文件路径
 *
 * @return hook函数地址
 */
unsigned long find_symbol_address(int pid, const char *function_name, const char *load_library_path) {
	unsigned long symbol_address = 0;
	LOGI("find_symbol_address...name: %s", function_name);
	ptrace_find_dlinfo(pid, &processinfo.ldl);
	if (processinfo.ldl.l_dlopen > 0) {
		processinfo.ldl.handle = (long)ptrace_dlopen(pid, &processinfo.ldl, load_library_path, 1);
		LOGI("find_symbol_address...handle: %ld", processinfo.ldl.handle);
		if (processinfo.ldl.handle > 0) {
			symbol_address = (unsigned long) ptrace_dlsym(pid, &processinfo.ldl, function_name);
		}

		// 获取被hook进程的start_hook函数地址
		const char *hook_name = "start_hook";
		processinfo.start_hook_address = (unsigned long) ptrace_dlsym(pid, &processinfo.ldl, hook_name);
		pint(processinfo.start_hook_address);
	}

	return symbol_address;
}

/**
 * hook目标进程中目标so库中的目标函数
 *
 * @param target_process_name : 目标进程名
 * @param target_function_name : 目标函数名
 * @param replace_function_name : 替换函数名
 * @param target_so_name : 目标so文件名
 * @param load_library_path : hook库文件路径
 *
 * @return 0 : hook成功; 1 : hook失败
 */
int inject_remote_process(const char *target_process_name, const char *target_function_name, const char *replace_function_name, const char *target_so_name, const char *load_library_path) {
	int pid = -1, result = 1;

	pid = find_pid_of(target_process_name);
	if (pid > 0 && get_elf_address(pid, target_so_name) > 0) {
		//sleep(1);
		usleep(500000);
		ptrace_attach(pid);
		char *so_name = find_file_name(load_library_path);
		unsigned long addr = get_elf_address(pid, so_name);
		if (addr == 0) {
			processinfo.pid = pid;
			pint(processinfo.pid);
			processinfo.symbol_address = find_symbol_address(pid, replace_function_name, load_library_path);
			pint(processinfo.symbol_address);
			if (processinfo.symbol_address > 0) {
				processinfo.function_address = get_function_address(pid, target_function_name, target_so_name);
				pint(processinfo.function_address);
				if (processinfo.function_address > 0) {
					ptrace_read(pid, processinfo.function_address, &processinfo.function_data, 4);
					pint(processinfo.function_data);
				}
			}
		}

//		if (processinfo.symbol_address > 0) {
//			processinfo.function_address = get_function_address(pid, target_function_name, target_so_name);
//			pint(processinfo.function_address);
//			if (processinfo.function_address > 0) {
//				ptrace_read(pid, processinfo.function_address, &processinfo.function_data, 4);
//				pint(processinfo.function_data);
//			}
//		}
		if (processinfo.function_address > 0 && processinfo.symbol_address > 0) {
			LOGI("replace...%08lx %08lx", processinfo.function_address, processinfo.symbol_address);
			// 调用start_hook函数
			if (processinfo.start_hook_address > 0)
				ptrace_call(pid, processinfo.start_hook_address, 0, NULL);
			ptrace_write(pid, processinfo.function_address, &processinfo.symbol_address, 4);
			result = 0;
			LOGI("replace...end");
		}
		ptrace_detach(pid);
	}

	return result;
}

/**
 * 恢复hook进程的状态(包含寄存器、函数)
 */
int restore_remote_process(const char *target_process_name) {
	int result = 1;
	int pid = -1;

	pid = find_pid_of(target_process_name);
	pint(processinfo.pid);
	if (pid > 0
			&& pid == processinfo.pid
			&& processinfo.function_address > 0) {
		write_pipe();
		ptrace_attach(processinfo.pid);
		ptrace_write(processinfo.pid, processinfo.function_address, &processinfo.function_data, 4);
		// 这里不关闭已经load的ELF文件，否则容易导致崩溃
//		if (processinfo.ldl.handle > 0) {
//			ptrace_dlclose(processinfo.pid, &processinfo.ldl);
//		}
		ptrace_detach(processinfo.pid);
		processinfo.pid = -1;

		result = 0;
	} else if (processinfo.pid > 0) {
		processinfo.pid = -1;
		save_info(&processinfo);
	}

	return result;
}

int main(int argc, char *argv[]) {
	int result = 0;
	if (argc > 1) {
		char *type = argv[1];

		bzero(&processinfo, sizeof(processinfo));
		get_info(&processinfo);

		if (strcmp("hook", type) == 0) {
			if (argc >= 7) {
				result = inject_remote_process(argv[2], argv[3], argv[4], argv[5], argv[6]);
				if (result == 0) {
					save_info(&processinfo);
				}
			}
		} else if (strcmp("restore", type) == 0) {
			if (processinfo.pid > 0 && argc >= 3) {
				restore_remote_process(argv[2]);
			}
		}
	}

    // end
    exit(result);
}
