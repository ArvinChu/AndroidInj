/*
 * global_function.h
 *
 *  Created on: Jun 4, 2011
 *      Author: d
 */

#ifndef JNI_INJ_GLOBAL_FUNCTION_H_
#define JNI_INJ_GLOBAL_FUNCTION_H_



#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>
#include <linux/user.h>
#include <stdarg.h>
#include <elf.h>
#include <errno.h>
#include "global.h"
#include "debug.h"

#define pint(_x)  LOGI("[%20s( %04d )]  %-30s = %d (0x%08x)\n",__FUNCTION__,__LINE__, #_x, (int)(_x), (int)(_x))
#define puint(_x) LOGI("[%20s( %04d )]  %-30s = %u (0x%08x)\n",__FUNCTION__,__LINE__, #_x, (unsigned int)(_x), (unsigned int)(_x))
#define pstr(_x)  LOGI("[%20s( %04d )]  %-30s = %s \n",__FUNCTION__,__LINE__, #_x, (char*)(_x))
/**
 * 判断该文件是否是*.so
 */
#define IS_DYN(_einfo) (_einfo->ehdr.e_type == ET_DYN)

// inject_info.c
void save_info(struct process_info *processinfo);
void get_info(struct process_info *processinfo);


// ptrace.c
void ptrace_attach(pid_t pid);
void ptrace_cont(pid_t pid);
void ptrace_detach(pid_t pid);
void ptrace_write(pid_t pid, unsigned long addr, void *vptr, int len);
void ptrace_read(pid_t pid, unsigned long addr, void *vptr, int len);
char *ptrace_readstr(pid_t pid, unsigned long addr);
void ptrace_readreg(pid_t pid, regs_t *regs);
void ptrace_writereg(pid_t pid, regs_t *regs);
unsigned long ptrace_push(pid_t pid, regs_t *regs, void *paddr, int size);
long ptrace_stack_alloc(pid_t pid, regs_t *regs, int size);
void ptrace_find_dlinfo(int pid, dl_fl_t *dlinfo);
void *ptrace_dlopen(pid_t pid, dl_fl_t *dlinfo, const char *filename, int flag);
void *ptrace_dlsym(pid_t pid, dl_fl_t *dlinfo, const char *symbol);
int ptrace_dlclose(pid_t pid, dl_fl_t *dlinfo);
int ptrace_mymath_add(pid_t pid, long mymath_add_addr, int a, int b) ;
void ptrace_dump_regs(regs_t *regs, char *msg) ;
int ptrace_wait_for_signal (int pid, int signal) ;
int ptrace_call(int pid, long proc, int argc, ptrace_arg *argv);

// elf.c
unsigned long get_elf_address(int pid, const char *soname);
void get_elf_info(int pid, Elf32_Addr base, struct elf_info *einfo);
void get_dyn_info(struct elf_info *einfo, struct dyn_info *dinfo);
unsigned long find_sym_in_rel(struct elf_info *einfo, const char *sym_name);
unsigned long get_function_address(int pid, const char *funcname, const char *soname);

// inject.c
int find_pid_of(const char *process_name);
unsigned long find_symbol_address(int pid, const char *function_name, const char *load_library_path);
int inject_remote_process(const char *target_process_name, const char *target_function_name, const char *replace_function_name, const char *target_so_name, const char *load_library_path);
int restore_remote_process(const char *target_process_name);

#endif /* JNI_INJ_GLOBAL_FUNCTION_H_ */
