#include "global_function.h"

void print_info(struct process_info *processinfo) {
	LOGI("info...%08d %08lx %08lx %08lx %08lx %08lx %08lx",
			processinfo->pid,
			processinfo->ldl.handle,
			processinfo->ldl.l_dlclose,
			processinfo->start_hook_address,
			processinfo->symbol_address,
			processinfo->function_address,
			processinfo->function_data);
}

void save_info(struct process_info *processinfo) {
	int result = 0;
	FILE *file = fopen(INJECT_PROCESS_INFO_FILE, "w");
	if (file != NULL) {
		result = fprintf(file, "%08d %08lx %08lx %08lx %08lx %08lx %08lx",
				processinfo->pid,
				processinfo->ldl.handle, processinfo->ldl.l_dlclose,
				processinfo->start_hook_address,
				processinfo->symbol_address,
				processinfo->function_address, processinfo->function_data);
		if (result < 1) {
			LOGE("fprintf %s errno %d", INJECT_PROCESS_INFO_FILE, errno);
		}
		fclose(file);
		file = NULL;
		print_info(processinfo);
	} else {
		LOGE("save_info can't open %s", INJECT_PROCESS_INFO_FILE);
	}
}

void get_info(struct process_info *processinfo) {
	int result = 0;
	FILE *file = fopen(INJECT_PROCESS_INFO_FILE, "r");

	processinfo->pid = -1;
	if (file != NULL) {
		result = fscanf(file, "%08d %08lx %08lx %08lx %08lx %08lx %08lx",
				&(processinfo->pid),
				&(processinfo->ldl.handle), &(processinfo->ldl.l_dlclose),
				&(processinfo->start_hook_address),
				&(processinfo->symbol_address),
				&(processinfo->function_address), &(processinfo->function_data));
		if (result < 1) {
			LOGE("fscanf %s errno %d", INJECT_PROCESS_INFO_FILE, errno);
		}
		fclose(file);
		file = NULL;
		print_info(processinfo);
	} else if (errno != ENOENT){
		LOGE("get_info can't open %s %d", INJECT_PROCESS_INFO_FILE, errno);
	}
}
