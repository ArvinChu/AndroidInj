Poison
======

Another of the Android platform injection tools, which made a special handling the Zyote process, solves the problems of injection Zyote process will be blocked
