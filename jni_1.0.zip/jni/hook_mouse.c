#include <asm/poll.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include "inj/debug.h"
#include "inj/global.h"

#define F_LEN 200

int start_hook() {
	int result = 0;
	LOGI("start_hook...%p", mkfifo);
	if (mkfifo > 0) {
		if(mkfifo(PIPE_NAME, 0666) < 0 && errno != EEXIST) {
			LOGE("start_hook mkfifo %s failed", PIPE_NAME);
		} else {
			result = 1;
		}
	}
	LOGI("start_hook...end");
	return result;
}

void read_pipe() {
	int fd;

	// check file exist
	if (access(PIPE_NAME, F_OK) != -1) {
		LOGI("read_pipe wait...");
		// waiting write open...
		if((fd = open(PIPE_NAME, O_RDONLY)) < 0) {
			LOGE("read_pipe open %s failed %d", PIPE_NAME, errno);
			return;
		}

		close(fd);
		unlink(PIPE_NAME);
		LOGI("read_pipe end");
	}
}

int check_mouse_device(int fd) {
	int result = -1;
	char filename[F_LEN] = {0};
	char fdname[F_LEN] = {0};
	snprintf(filename, F_LEN, "/proc/%ld/fd/%d", (long)getpid(), fd);
	if (readlink(filename, fdname, F_LEN) < 0) {
		LOGE("check_mouse_device readlink errno %d", errno);
	} else {
		LOGI("check_mouse_device %s", fdname);
		if (strcmp(fdname, "/dev/rj_input1") == 0) {
			result = 0;
		}
	}
	return result;
}

int poll_local(struct pollfd *pollfd, unsigned int nfds, int timeout) {
//	check_mouse_device(pollfd->fd);
	read_pipe();
	return 1;
}
